-- MariaDB dump 10.19  Distrib 10.5.12-MariaDB, for Linux (x86_64)
--
-- Host: mysql-5.7-3306.database.nitro    Database: craftvue_db_dev
-- ------------------------------------------------------
-- Server version	5.7.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `pluginId` int(11) DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_dgnumxjgvwshmrskqzwvdlefisfsqazhyydh` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_unqjhnkwdvujoxhcrayftpwsslkthjzhdayh` (`dateRead`),
  KEY `fk_qalzhnjfbbsmcsfmhqzsslczznxneycthnns` (`pluginId`),
  CONSTRAINT `fk_cfjgvvjfapkmbmtjjoqvbqdiuzvzehovxrfc` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qalzhnjfbbsmcsfmhqzsslczznxneycthnns` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` varchar(36) NOT NULL DEFAULT '',
  `volumeId` int(11) NOT NULL,
  `uri` text,
  `size` bigint(20) unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `recordId` int(11) DEFAULT NULL,
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qjkflekayzbsolrgjwnniqkbftlpncsweyym` (`sessionId`,`volumeId`),
  KEY `idx_hocjpfezdfurdvlmprddfgrrelubkaoueeko` (`volumeId`),
  CONSTRAINT `fk_zisoywyflgezyyscfozorfbtonwgzdmsicfk` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets` (
  `id` int(11) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `uploaderId` int(11) DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_clgzpgyqihcncldsfjbiijtferhwmmwqoxdo` (`filename`,`folderId`),
  KEY `idx_zvkwyzeyeitkipwkwrjmeainnercxvuodtew` (`folderId`),
  KEY `idx_fxsppjcqsztoupohadhhrwnstuzhrnqienol` (`volumeId`),
  KEY `fk_bqttizlyyxdvtdpkcsymibsonfpeeihywzmg` (`uploaderId`),
  CONSTRAINT `fk_abbxmnsrxbvflwyfpqyiqktvyovkwpnrhjro` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_bqttizlyyxdvtdpkcsymibsonfpeeihywzmg` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_iedhbrfaahdvwkxhepdsknobwishgsaignao` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pgyealezkpacsnqgdjnoukskcgnqrpsflewy` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assettransformindex`
--

DROP TABLE IF EXISTS `assettransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assettransformindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assetId` int(11) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `location` varchar(255) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qocvldmptuqptbeonwrdborgtrmgqruseplg` (`volumeId`,`assetId`,`location`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assettransforms`
--

DROP TABLE IF EXISTS `assettransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assettransforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `dimensionChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_suqdjbetpiufabmcqfegqlnqdxvsqgbmombi` (`name`),
  KEY `idx_jotlthgoyylwfmdvhlwyyhikpdurfoypwwqc` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_toibtcpphawbopntcrkgfrdpdbylxoqqkntz` (`groupId`),
  KEY `fk_zdscwvtfzctbdkdomzstjardzyopjqhzjvxk` (`parentId`),
  CONSTRAINT `fk_wlqsefnuudqozwfrwdnuthbifusqcryuxsxj` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yuqbygrkfccycvflopabwtvrogomduqhorrj` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zdscwvtfzctbdkdomzstjardzyopjqhzjvxk` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bokfxyxjibnkpkrdwcwlfssezxzhkoiyhhxf` (`name`),
  KEY `idx_amgwlrptmrsdndsnjejnstystfonmgovrqif` (`handle`),
  KEY `idx_iqwzepgkgnqujjadqkspbgeswbghgkptexnr` (`structureId`),
  KEY `idx_hcosqppgevgcdyslfijkwxvtuuzurxfzqwpj` (`fieldLayoutId`),
  KEY `idx_hjptugjbpcvzawttnisftnzmfiauiofemldx` (`dateDeleted`),
  CONSTRAINT `fk_dgqpokcgdpdfbwktigemtqybdbsbklgumipp` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_zixewefjsrnmfosszcllrmpsxqyvqngqmsvv` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wflijtijimfkymmejawmfsxbcxwsgxumiwfe` (`groupId`,`siteId`),
  KEY `idx_koxxczjdmbsicrvxguyvstfolyjunxddculf` (`siteId`),
  CONSTRAINT `fk_dnbmmgcbhdrgyatxldyuyrsohixsuaeioist` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wrxxytezulbyczqxxpcvsrirdjllngxrugdi` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedattributes` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_lkczbljjcyvglydczmrffjeuknwevoyqrsmr` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_dwwswhhblekmhjpaoqphcezlahaiycoqofso` (`siteId`),
  KEY `fk_bxrqkgttrqjuloecycdudglgmtdjvfxbeojx` (`userId`),
  CONSTRAINT `fk_bxrqkgttrqjuloecycdudglgmtdjvfxbeojx` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_dwwswhhblekmhjpaoqphcezlahaiycoqofso` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_enxmecxtdedwqkhzreesfkxiqluusnwvnilw` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedfields` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`),
  KEY `idx_onsuhpwcwjiqmgmlwixulsqnhsxdhbfyvfqf` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_pzpwwwasyfvdkxjrwyltzsnhzdnfbzssgtmh` (`siteId`),
  KEY `fk_gszvbtxgjfdbzevbjmoqisjixhcyvvxxlllc` (`fieldId`),
  KEY `fk_eajqttoiyfmtkmhjrxcxcgcpfbqzgthzhgxs` (`userId`),
  CONSTRAINT `fk_eajqttoiyfmtkmhjrxcxcgcpfbqzgthzhgxs` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_gszvbtxgjfdbzevbjmoqisjixhcyvvxxlllc` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_pzpwwwasyfvdkxjrwyltzsnhzdnfbzssgtmh` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_wnvhhyvfnmuohqxpgpfuzesitjdelnjiucqo` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_aivuuqfelsyjaqakrmsxxjcprzlnsbgpxldh` (`elementId`,`siteId`),
  KEY `idx_libcmalvnatntbmpzphsntwiephlfkrfvgef` (`siteId`),
  KEY `idx_zmopsrbpobpjaywmkuvsmjagrdvrxhrvykru` (`title`),
  CONSTRAINT `fk_pbnyiljdbiquyyviocbzefscrjrubstkvvqz` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_svezncpswvmpzajfhifzcxmtjotulztxenyr` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craftidtokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_wigfmoabsfjxqrgtrnkxiyjjmffhucljvmti` (`userId`),
  CONSTRAINT `fk_wigfmoabsfjxqrgtrnkxiyjjmffhucljvmti` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deprecationerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint(6) unsigned DEFAULT NULL,
  `message` text,
  `traces` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tajsnlknsawrtvogxcefrkcmvqwhbukqswgs` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sourceId` int(11) DEFAULT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_dlvlgbbidwlzatsqczilsvvdsvgchkdlkuid` (`creatorId`,`provisional`),
  KEY `idx_wwcnsbgcsqsjwvdswtnilhpemiirjydxzqvi` (`saved`),
  KEY `fk_akfcddwcctllqboscvzsdoyjmttrnxybgiik` (`sourceId`),
  CONSTRAINT `fk_akfcddwcctllqboscvzsdoyjmttrnxybgiik` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ftubughfwbuleimajhlbwnpnhjltlmrdwuqn` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elementindexsettings`
--

DROP TABLE IF EXISTS `elementindexsettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elementindexsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ownfwwdgdyuknehiotvxalqtvpaiwayybkcx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) DEFAULT NULL,
  `draftId` int(11) DEFAULT NULL,
  `revisionId` int(11) DEFAULT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hlhngubrkforldnlgexkgyzwwdwxcoyhjbxi` (`dateDeleted`),
  KEY `idx_rvmdcdtptqgegrztrkattsgyorpfbdvnedep` (`fieldLayoutId`),
  KEY `idx_izougttvjzcwslzkwfzfsdeqakmsvmzpkxjf` (`type`),
  KEY `idx_niplihvgxkbtsrlryscmhvazodhndgctxqsf` (`enabled`),
  KEY `idx_ovldbsamuagycsoxqmpoqylywwfwhjshbbad` (`archived`,`dateCreated`),
  KEY `idx_lggxkdjnpavhfhtcmcambcnokmyabbwsitum` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `fk_zqidtgjqivpxyjnafmkaiimvgizobrqcfwzv` (`canonicalId`),
  KEY `fk_mgaxsrfxpwpwrbycdzdovijnmsjkbwaryqgc` (`draftId`),
  KEY `fk_feptkpzttsapbbfanfrwdupkfsesuxiegmid` (`revisionId`),
  CONSTRAINT `fk_feptkpzttsapbbfanfrwdupkfsesuxiegmid` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mgaxsrfxpwpwrbycdzdovijnmsjkbwaryqgc` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wwkosnhmdtyxtgjrsaxkbatyxrpkxadmznna` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_zqidtgjqivpxyjnafmkaiimvgizobrqcfwzv` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_knfolzcjvfmxkrsbrqftstwtpuokzausyvos` (`elementId`,`siteId`),
  KEY `idx_rgyexlbcgiqnershfuwdfivdfmhzdqbnfzcy` (`siteId`),
  KEY `idx_uyhqbejwpsfddawzcikateywsoyobsvzwytr` (`slug`,`siteId`),
  KEY `idx_hzrnmotzcbfaqazegahcqimduezszrqycekw` (`enabled`),
  KEY `idx_ixfggoudwxcxthfyrapitvnbcaliuhqwmnfi` (`uri`,`siteId`),
  CONSTRAINT `fk_urrgrjnbrepkhtkjugduqjtmujuvdnbyubtf` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_xlnptuubhfsibmfepxkwyguzjdwvmdvbqdcv` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `typeId` int(11) NOT NULL,
  `authorId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_iuetdnclyqsdswzvpegeorvohbejxofwfzsc` (`postDate`),
  KEY `idx_btbbvkwiyjgzepvdtyxlvwsljdtjnwddgvzq` (`expiryDate`),
  KEY `idx_kstnrrqchjjivxsvjxzzfksfjhmrhhcezgta` (`authorId`),
  KEY `idx_dnjxuhjrzbtqfzivgksttytxlgnhpckgmtdo` (`sectionId`),
  KEY `idx_scinypwvynhsuiisowwtsiulvrqwwnvvabsa` (`typeId`),
  KEY `fk_ahuwjofvbjhdcswfpvtqphtviusnomhbjvor` (`parentId`),
  CONSTRAINT `fk_ahuwjofvbjhdcswfpvtqphtviusnomhbjvor` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_pogawbndlrtttpdushwxvbtzjiakowfcyloh` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rgjnjrxhpybgncivmmpnvqcsclxgdcuhsarw` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tsaebuzkamrrnviiewlmpfajbqngqsekmbum` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yvnrgqenrncznnlqwtbwbpsfxterxoeofvnx` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hkcmigqleafrxefjpbuvoeyoesqdtsxsextv` (`name`,`sectionId`),
  KEY `idx_xkwnihxqkleobuvarcjbjrfmyrphmqxcivxz` (`handle`,`sectionId`),
  KEY `idx_kqwvotgckchhtamzndzbyqaukkddydmmmnnw` (`sectionId`),
  KEY `idx_etucyyncqccwfxtecplhrsjkvzereydcoszm` (`fieldLayoutId`),
  KEY `idx_wfwakjjoyoqmcqancigemabdykmqueczbjxj` (`dateDeleted`),
  CONSTRAINT `fk_flkvicnfelcvhirwhbghksixllzkvqkdohhy` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_opsmpombvxjhpwjamxxhhtwwzaacjltxdkvh` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qlnngaocdjvlhjymowgmhkqjtvrqjxpenfed` (`name`),
  KEY `idx_kpydzfawlnnzxqywqcodlhvotflctpflxfvp` (`dateDeleted`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayoutfields`
--

DROP TABLE IF EXISTS `fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayoutfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `tabId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ijmcxpxmlubwdxaewtzmvedatmtqfkodfkvr` (`layoutId`,`fieldId`),
  KEY `idx_tedmgjadedkrhcaqtnshszkrgapitlidwhsm` (`sortOrder`),
  KEY `idx_lrvffkczstjqknzrzqvdxfgwnckvqlmjwqqf` (`tabId`),
  KEY `idx_pdjhgfxmwspokxushtfjacswxlaegvzmfvlj` (`fieldId`),
  CONSTRAINT `fk_gbbaorkmiqpvpvjbvvhqhqetsdjpxiyefcea` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hkxcezfsxazrewtwouytuzpqgnuhxogxgczw` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kgjbevpjsvahisuqrjbevddyvpvmeyjhqdwk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zimcftqasdkhblglxpyuhriyvuppfzswnryw` (`dateDeleted`),
  KEY `idx_zdolggajchmjjgotqvqjxetpyxtzljhssrkt` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouttabs`
--

DROP TABLE IF EXISTS `fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouttabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `elements` text,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tbmfpdxrszcdrewkwzhscdwebiajuzvflmmr` (`sortOrder`),
  KEY `idx_rvhjtkrkysuejtmvehifhsonhawldmskiprl` (`layoutId`),
  CONSTRAINT `fk_tabjlnudolaswlfuxlhcoegnkezmwfczzyqj` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xrpnqefutkemodwzykzhpumwifbnugwxtbjd` (`handle`,`context`),
  KEY `idx_vfnmikrvrcsskkdijjzvwycrnptucxczkkcq` (`groupId`),
  KEY `idx_pdbynheinpafrczyegzhewyciixychfeythh` (`context`),
  CONSTRAINT `fk_fqfgbrqysdwdkuebuoyprcpmuuwvizzartkb` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `globalsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fhstomadqoxlnjiyzyjdmnxzuzmowlcafttf` (`name`),
  KEY `idx_feiqcrcocaxdrlswmgtlbbrcwjyoxlemztsv` (`handle`),
  KEY `idx_zfhknxbnawjzczpzjgpzdilbwxwvcczeiiuj` (`fieldLayoutId`),
  KEY `idx_amvlnpxlhvssbxaqvzgjgpzoyeprtgleudnq` (`sortOrder`),
  CONSTRAINT `fk_nfzjtxwledudmfmrobsoivqprruzrluidniy` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sejimhvpoldejvzbsiibqrnjmpxhcfkroxfq` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqlschemas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` text,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqltokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dmzvpwfcoxvohrtdegmxrxnjbzyrhujbnqao` (`accessToken`),
  UNIQUE KEY `idx_mtvxztkhvbaqrzviagfoeielpwdhtcxkoazo` (`name`),
  KEY `fk_hzdsizgygrseqsicwhshjmnlblfsukftikli` (`schemaId`),
  CONSTRAINT `fk_hzdsizgygrseqsicwhshjmnlblfsukftikli` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocks`
--

DROP TABLE IF EXISTS `matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocks` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kquszkprxdaqguccqrtxpmqshfmwywzrnhtk` (`ownerId`),
  KEY `idx_psfgjjrctsrjricybsvyfcrylocjuermgigo` (`fieldId`),
  KEY `idx_vyivhzwdkblrmojexmxnloqsuydofymmyyhc` (`typeId`),
  KEY `idx_hmdvwhtgzlcdvgwhvuxxhqlolfutpcbvbjul` (`sortOrder`),
  CONSTRAINT `fk_kzulscwgvhrdtegvmehhlmuiyrafyrlhptmf` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lgwnfouemfeahfpyayibpjhdxoxgozbtmlyx` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pgjhhwgzcgtkxdhqekpeyapxfpsfdjqynzka` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ylnourhluwmfftcbrsdcgpnaeitfxwayjjbz` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocktypes`
--

DROP TABLE IF EXISTS `matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ggrssircdwsnehjkanyrqfycrrgngbahznms` (`name`,`fieldId`),
  KEY `idx_gstxdjimzpxcshkfchsqfssjoeqrwdeboxhj` (`handle`,`fieldId`),
  KEY `idx_txfoevfdnocdkppmmbyhknrsynmyvkkxuzad` (`fieldId`),
  KEY `idx_uzszjnxadtudpzqalxmszrsfiwdcjdnimzgv` (`fieldLayoutId`),
  CONSTRAINT `fk_vnbffslddukpnxsnviezgxltnwkvxbgwxvhg` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_yuvxgepmpaxyaeteitgiyvpvdovmtpmhxwae` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_sxszszywvuuxshcdrczvvbdeviadwhicppif` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=192 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `licenseKeyStatus` enum('valid','trial','invalid','mismatched','astray','unknown') NOT NULL DEFAULT 'unknown',
  `licensedEdition` varchar(255) DEFAULT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rcdtclphviyefkmjazrsiogclcgoiyoqeqwb` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT '0',
  `priority` int(11) unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int(11) DEFAULT NULL,
  `progress` smallint(6) NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int(11) DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_fiswhqvfblhgbmzxivadrgappycpwfaesllp` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_vtpmszpuyjhvzreyifizhzfvpkagzjszqmor` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceSiteId` int(11) DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ogtzoygqhixuatzzeprkffrwhlwekexitnxd` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_yndyfezweqnqdjmyctpophaafftrzlsschuv` (`sourceId`),
  KEY `idx_nwuqcdceaewncphdhjxcbxyrfoivnskjygbz` (`targetId`),
  KEY `idx_gzfcyrtyfohtsqrarnutmixvlbdekkoznfvp` (`sourceSiteId`),
  CONSTRAINT `fk_baowqjaehyxryigrxlymlfmagbubbtkizyyd` FOREIGN KEY (`targetId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_merpauzoesuuthyisqzkkofwvxbasiubyfll` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_poiugydodxeqschhufaeaditvdckjrnuvexd` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wpamfnkjijvqnzzsdwnrkzrpfislkrkryjem` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revisions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sourceId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `num` int(11) NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kpuzugxajlokhcmmgaygyysuuvcxsnegrwux` (`sourceId`,`num`),
  KEY `fk_ouveazvmlbisscsignyupxespolcmykwichx` (`creatorId`),
  CONSTRAINT `fk_hadrnlnnymsumvzcfpswueexfnglxmqtvuxi` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ouveazvmlbisscsignyupxespolcmykwichx` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_ohzwrzwlrlqkztqumzuhnzvkzilclrxzdbfo` (`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rgtqwcwatdzgtmksoaytjlhcotkplhvhktps` (`handle`),
  KEY `idx_gipilqyicznnsuhlwttjzxdynalhyphniydv` (`name`),
  KEY `idx_sgwfmxldnkoemfmkbjxccruhusjahcitdlbw` (`structureId`),
  KEY `idx_vhchzgfhpqdpqcyzkixjvcjwtxflarrzmjpy` (`dateDeleted`),
  CONSTRAINT `fk_zxdfmfrleafwmfsthxhmyenmhsboswgdntsp` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zwcjvpxkqwbqsvgowiuematofypyerghtxon` (`sectionId`,`siteId`),
  KEY `idx_zzcclwwatbndyjlooasilhtjvwfeoewcjkqg` (`siteId`),
  CONSTRAINT `fk_rebzejzyremgsjavhohszicyehkhaoyejqre` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zpkljjbxzuipgcunfsydgabunmngeozeaqsz` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int(11) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zovmnxglkqyqhrwqljstvehryygagafvjqgk` (`uid`),
  KEY `idx_lyyxsdzfxqupgkjhsqzibfzgkqazjitdtjaq` (`token`),
  KEY `idx_qusxhaxyxsjeavglhmqmqfezicuasnbubvoc` (`dateUpdated`),
  KEY `idx_lvufwcdxodsrjrtvukhbksfqnhhpdqyydcrw` (`userId`),
  CONSTRAINT `fk_aqgfrldueduzgjqdegdjfslxktcwoqspdden` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shunnedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_eqxknojrmsepapoanjklizvsdepuhauittsx` (`userId`,`message`),
  CONSTRAINT `fk_ajgtjofktqucueyvcmmargkpqvlloqynndwr` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sitegroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xhlpyxpmiittujccmokexfaicjjzplozbmgu` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bkifhtjrryyslskmrdzehucragqpialrixte` (`dateDeleted`),
  KEY `idx_psqvnqimubfsoytylneoylbwdfyofsxpjols` (`handle`),
  KEY `idx_xtixdbydevnebfvtwspgalyqgsrvatqbzzxw` (`sortOrder`),
  KEY `fk_nfxqqwfbucegsfxucxleakcqgnzpvhoqfumd` (`groupId`),
  CONSTRAINT `fk_nfxqqwfbucegsfxucxleakcqgnzpvhoqfumd` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structureelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_jijwbwcaksqchplmoxadcaxebokuiuhfrllz` (`structureId`,`elementId`),
  KEY `idx_plyyrrzkajlnluiorbhmqqrityomzwopdvdt` (`root`),
  KEY `idx_antseldmcgiyhwkdizeqsvpizbaeabxryfyc` (`lft`),
  KEY `idx_xrrhwsbvvsqkrgllxryvuhdxwtiyitgszabt` (`rgt`),
  KEY `idx_aiymkzzccjtsemcnchowfcjtiwmtcllkvcgg` (`level`),
  KEY `idx_apubnmiadtrpzeiscnroomirtkvnsqygglcc` (`elementId`),
  CONSTRAINT `fk_adhncxviyzpawizylgfoycmjjhbwsgspetyd` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zxucvhhfylzzdldwhrcpuicerptyebtrwqgv` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_frxtqmbkxymciscgbajssbbvmfkodjowswlq` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lgfpqfpkhvxfqnlpakwhiigdoxiuqgczzwwf` (`key`,`language`),
  KEY `idx_bxcfomxbfnyfwmkbzcyjgnxiqbztbjpwxvob` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bawcnnutohzlpfgayboinvvjqsdvmtjphirx` (`name`),
  KEY `idx_bpqutpwbybwstzlpywpemoprlqgoxincnznz` (`handle`),
  KEY `idx_fmcpryfknffyfakcdygsvusyyfohyrcuffdp` (`dateDeleted`),
  KEY `fk_nqawfmzuynkcshcqvdkfvjshridzfhkrboxx` (`fieldLayoutId`),
  CONSTRAINT `fk_nqawfmzuynkcshcqvdkfvjshridzfhkrboxx` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lzlomtnvaurssbmjsfrrdmdmwrajjjxlacvu` (`groupId`),
  CONSTRAINT `fk_csmaqsfeychluxhbkoyaixzrswyxdwkqjlft` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lxtnnrfgldblrskqnbzcbqqpbjvzplopulxx` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `templatecacheelements`
--

DROP TABLE IF EXISTS `templatecacheelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templatecacheelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cacheId` int(11) NOT NULL,
  `elementId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_psgisabhvrddgeqsjdicxnhdubcbvucdzosn` (`cacheId`),
  KEY `idx_qbbmgzztoxdyzokglpvygdqeyjtjsnhcaoez` (`elementId`),
  CONSTRAINT `fk_austycfxmivpkkwumbmrgxzkkgmzffigbytr` FOREIGN KEY (`cacheId`) REFERENCES `templatecaches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gctzfwydnenghnkjwvustkrtoqlhqewngixe` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `templatecachequeries`
--

DROP TABLE IF EXISTS `templatecachequeries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templatecachequeries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cacheId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `query` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_zbbcybvnnvorkdnnqdldyevqeharpjjoultu` (`cacheId`),
  KEY `idx_gyjonwsyyjwyhwjansjviytckfuvscrdotgj` (`type`),
  CONSTRAINT `fk_ewxnytwipvlckfmliqxcglfaxvqxccehxekj` FOREIGN KEY (`cacheId`) REFERENCES `templatecaches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `templatecaches`
--

DROP TABLE IF EXISTS `templatecaches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templatecaches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `siteId` int(11) NOT NULL,
  `cacheKey` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `body` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_vxmthcxsjzqorhpbnonbssbwmpyrfuugypdz` (`cacheKey`,`siteId`,`expiryDate`,`path`),
  KEY `idx_hewgnwglmtthnbduxedsvzgjbqjcorgdrljt` (`cacheKey`,`siteId`,`expiryDate`),
  KEY `idx_ywpwyamjszofhgliqxdzbewcrkgtvmztpvma` (`siteId`),
  CONSTRAINT `fk_wntjzngwxflqkxnmcdvcwskxfdgahtrvekwh` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint(3) unsigned DEFAULT NULL,
  `usageCount` tinyint(3) unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dzytufwtoqayomoblusczybtxlumltpzzjcu` (`token`),
  KEY `idx_pkvcxomqzizxjlygewxrunnknaziiyxkzvjt` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tttzxkscsdszxavkifesbwdnshvizeryssij` (`handle`),
  KEY `idx_ymqcqtixuuicguzfnvoktueclftbxmsabffd` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ggmraettkvoqvixwuqjyeusbkrvetooaqlfq` (`groupId`,`userId`),
  KEY `idx_krrugwejqvnszovhmjcvtcifrcjodtrrdtls` (`userId`),
  CONSTRAINT `fk_jxljoptovtiszdvotxunzbtlviybojyjrmqa` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oroyfvnwzvzdnbqfdypaumrykbdxattrxtpv` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zhrafrckrmnuoxmuziuiwphumvarddqmkryk` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vqepmurigdczeqjxgkgaszcffdkwjlazqrjb` (`permissionId`,`groupId`),
  KEY `idx_trewwczwuymophkvysxkffproxxcaseoxled` (`groupId`),
  CONSTRAINT `fk_grsojawxdhukwzayirpdddvxzyppyegxpuol` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vdzpreqjzawodcvfjsvqitqgjogzaisetvcy` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gzyjzytrtstkcqevvunflfevgoimadggmvyn` (`permissionId`,`userId`),
  KEY `idx_ftrwtpypgqpqoefqrfdskpgphrwsxcuyjpjz` (`userId`),
  CONSTRAINT `fk_fjodwivcllpxucvuftkqtfmetomajxniqjxf` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_osrunksnxahfugradqhimrsyuwduygguyxqr` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpreferences` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `preferences` text,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_tpsvdifcncictihpjymnhxqspsaxqlrgpupz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `photoId` int(11) DEFAULT NULL,
  `firstName` varchar(100) DEFAULT NULL,
  `lastName` varchar(100) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint(3) unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rtyqdkwzclfwuyaqkdzygpowxqxftysvxdkt` (`uid`),
  KEY `idx_lomhrexsnnakkybkzotkykoghuwjrvvjchjf` (`verificationCode`),
  KEY `idx_jkkiibhextfaouuawhgkqfdvbygfegmdanwu` (`email`),
  KEY `idx_hcjlbraaaibsjktbppppymtchvtmbbxdivpv` (`username`),
  KEY `fk_dsfutggeqhgcssxjivjjzpwcblodxkjmlbpn` (`photoId`),
  CONSTRAINT `fk_cnbbdecsmsldtqjcgdfxcxvpqegfjkxiyxon` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dsfutggeqhgcssxjivjjzpwcblodxkjmlbpn` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumefolders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rniifoyisynbiqwhmuzcarnkkcqsdmxaiimd` (`name`,`parentId`,`volumeId`),
  KEY `idx_tcmouyvmyornbzaewoiuiizzycoutuesbzwq` (`parentId`),
  KEY `idx_bskxzmstlmsxjljvsfupqefkgbbavbrnngbp` (`volumeId`),
  CONSTRAINT `fk_fqbyrsqomjuezeemmosmripaiezznepowmmw` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vouyoagmzeknusvoymtjzyhpsfwahcamutqz` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `url` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `settings` text,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qqwleufaxgtxjgzczztrxnhidstdmmoxqjum` (`name`),
  KEY `idx_eizhuyzozcziexobxwsapdvdeioqnveowxpj` (`handle`),
  KEY `idx_idbmltvhatwahunjnwpsaouqvijhxexrxrgn` (`fieldLayoutId`),
  KEY `idx_hcnhpmvcvocsebhcnfaqcaedkifoprhcqyyq` (`dateDeleted`),
  CONSTRAINT `fk_efxumfkwrstoyxkmhwspojlcdkhklteejqnx` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `colspan` tinyint(3) DEFAULT NULL,
  `settings` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_telrwuvcfscicvugrrdeaocgovarfxpzmmos` (`userId`),
  CONSTRAINT `fk_eylruocyfusbhvqbstbxearghsjuzipbegpc` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'craftvue_db_dev'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-13 20:19:43
-- MariaDB dump 10.19  Distrib 10.5.12-MariaDB, for Linux (x86_64)
--
-- Host: mysql-5.7-3306.database.nitro    Database: craftvue_db_dev
-- ------------------------------------------------------
-- Server version	5.7.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assettransforms`
--

LOCK TABLES `assettransforms` WRITE;
/*!40000 ALTER TABLE `assettransforms` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assettransforms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `content` VALUES (1,1,1,NULL,'2022-01-13 16:08:04','2022-01-13 16:08:04','8460d06c-ac1c-4b68-b8d9-5ff3e60a5b3b');
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elementindexsettings`
--

LOCK TABLES `elementindexsettings` WRITE;
/*!40000 ALTER TABLE `elementindexsettings` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `elementindexsettings` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2022-01-13 16:08:04','2022-01-13 16:08:04',NULL,NULL,'ae9bb02b-549b-45ad-8df0-88aeaae241dd');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,1,'2022-01-13 16:08:04','2022-01-13 16:08:04','2575d849-5494-4171-ae88-cec8aba9f787');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldgroups` VALUES (1,'Common','2022-01-13 16:08:04','2022-01-13 16:08:04',NULL,'76566381-39cb-4a0a-979e-9ba75b430b12');
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayoutfields`
--

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouttabs`
--

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `gqlschemas` VALUES (1,'Public Schema','[]',1,'2022-01-13 17:28:16','2022-01-13 17:28:16','b3e1d1ca-562d-48d1-9935-82d27aa939d9'),(2,'Frontend','[]',0,'2022-01-13 17:28:50','2022-01-13 17:28:50','e9cad64a-269f-458b-983e-4f839f117801');
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `gqltokens` VALUES (1,'Public Token','__PUBLIC__',1,NULL,NULL,1,'2022-01-13 17:28:16','2022-01-13 17:28:16','09057653-bb28-4f38-b9f9-5574ffae0962'),(2,'CraftVue','czhm23589yvt4U3W-ooc_UQc9O02tHl1',1,NULL,NULL,2,'2022-01-13 17:31:22','2022-01-13 17:31:22','e4d4fe4a-c553-42e7-8e28-d868398ba526');
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `info` VALUES (1,'3.7.28','3.7.8',0,'ojoephxvvamn','2@zhdlatoftw','2022-01-13 16:08:03','2022-01-13 20:16:49','a5c3b96a-6c48-40ca-b0f8-11a63822d464');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocks`
--

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocktypes`
--

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES (1,'craft','Install','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','9ee4cbf5-0384-4b55-8c01-81f34f43871a'),(2,'craft','m150403_183908_migrations_table_changes','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','a5235bb4-59ae-4e67-a423-551cd0d0420b'),(3,'craft','m150403_184247_plugins_table_changes','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','b376a750-1bb5-475d-99fe-caf3e4c78a6b'),(4,'craft','m150403_184533_field_version','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','f8e7396e-b4f3-4c88-915f-ca4b6f22a356'),(5,'craft','m150403_184729_type_columns','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','009e2684-b6e9-4002-825e-7f9272df7296'),(6,'craft','m150403_185142_volumes','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','02c70940-3f81-4769-a2f9-631b6f773031'),(7,'craft','m150428_231346_userpreferences','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','9272381d-a5b1-431a-a7a9-ed1d46458feb'),(8,'craft','m150519_150900_fieldversion_conversion','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','3334c5ee-6fbb-498b-ad87-86b7f9c19339'),(9,'craft','m150617_213829_update_email_settings','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','4b8366ac-7383-44f6-9a24-395103d2ed07'),(10,'craft','m150721_124739_templatecachequeries','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','eb56fdc3-3103-48c0-9b72-d0089a6f14c6'),(11,'craft','m150724_140822_adjust_quality_settings','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','06d64e1c-7654-4775-b6e2-fb4c070342db'),(12,'craft','m150815_133521_last_login_attempt_ip','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','308e3001-a494-403c-b5a4-ad6962501d70'),(13,'craft','m151002_095935_volume_cache_settings','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','c6cc2ee3-9bf2-4349-a0e9-bde5382be051'),(14,'craft','m151005_142750_volume_s3_storage_settings','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','ffa13c15-d1cb-4243-a026-26423f38d067'),(15,'craft','m151016_133600_delete_asset_thumbnails','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','ebb67b97-02ee-4d84-ad9e-76b4d4e3a78f'),(16,'craft','m151209_000000_move_logo','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','51d00381-cd7f-44e2-9884-576177080e3f'),(17,'craft','m151211_000000_rename_fileId_to_assetId','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','102b528a-8abb-4ca2-a7a8-3e5c562f5a3f'),(18,'craft','m151215_000000_rename_asset_permissions','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','6a75f17b-2217-4677-b252-523fc3568582'),(19,'craft','m160707_000001_rename_richtext_assetsource_setting','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','a174a086-ef27-4aeb-8319-65554bb6570b'),(20,'craft','m160708_185142_volume_hasUrls_setting','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','10d6314e-6665-4722-a6db-861406cb47c0'),(21,'craft','m160714_000000_increase_max_asset_filesize','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','15813f5c-2f81-4cc7-88b6-a85b3f706e54'),(22,'craft','m160727_194637_column_cleanup','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','5224616f-ae7d-471c-902b-b349f943aef7'),(23,'craft','m160804_110002_userphotos_to_assets','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','253e9505-ccbd-4f59-9c3e-5991103ae4a7'),(24,'craft','m160807_144858_sites','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','0a9af6b3-be3c-4625-b785-df82420c3a87'),(25,'craft','m160829_000000_pending_user_content_cleanup','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','fdac358a-66c5-45d9-84b5-d22297ed3b36'),(26,'craft','m160830_000000_asset_index_uri_increase','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','b9c05362-80ca-49db-870d-924f1d76aa38'),(27,'craft','m160912_230520_require_entry_type_id','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','fd8e2703-6e8e-4cd5-950f-40bd84000ea2'),(28,'craft','m160913_134730_require_matrix_block_type_id','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','b0f573f5-c0c0-4eca-b9b0-7e0e1cf2453b'),(29,'craft','m160920_174553_matrixblocks_owner_site_id_nullable','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','01a4b409-6611-4333-9574-dfb198c3b5d0'),(30,'craft','m160920_231045_usergroup_handle_title_unique','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','380d3210-15dc-431b-8ef6-1713af4b9a82'),(31,'craft','m160925_113941_route_uri_parts','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','23bb49cc-916e-4bdf-a7cb-a32565632894'),(32,'craft','m161006_205918_schemaVersion_not_null','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','41beb107-2ea0-4d68-b340-df9b4ca7d416'),(33,'craft','m161007_130653_update_email_settings','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','e720e85e-9616-4344-b8a7-2bfb1584cc8c'),(34,'craft','m161013_175052_newParentId','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','c3727ade-e4f7-4b82-99b2-838470eeca03'),(35,'craft','m161021_102916_fix_recent_entries_widgets','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','975f188c-9016-47ec-8d2c-72d764b894d9'),(36,'craft','m161021_182140_rename_get_help_widget','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','b34c59e3-0568-4f60-b18c-7b17ef7d830f'),(37,'craft','m161025_000000_fix_char_columns','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','3cc0c238-d03e-4d6f-beff-bad529abcd4b'),(38,'craft','m161029_124145_email_message_languages','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','21f9c30d-0a9a-4298-aaae-ab8902d03ee4'),(39,'craft','m161108_000000_new_version_format','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','e96bac5c-1b34-42a1-b439-5d7f05a1ced7'),(40,'craft','m161109_000000_index_shuffle','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','ba1ece35-f219-4ba1-806b-db302fc76de1'),(41,'craft','m161122_185500_no_craft_app','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','814f8731-d0fc-41d5-9f4f-b3a3358f3086'),(42,'craft','m161125_150752_clear_urlmanager_cache','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','91765bce-5b5b-469d-ad10-8971aceb9dce'),(43,'craft','m161220_000000_volumes_hasurl_notnull','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','f2737fbd-f017-4430-8ab0-e16b9fa4d6c5'),(44,'craft','m170114_161144_udates_permission','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','5ea7a6af-b905-4e05-9fb2-c6fea5863aab'),(45,'craft','m170120_000000_schema_cleanup','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','0bf68e17-1972-411e-8165-92846dec795b'),(46,'craft','m170126_000000_assets_focal_point','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','a2482d1b-5e5d-451c-bdd5-2fbd695c4564'),(47,'craft','m170206_142126_system_name','2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 16:08:04','857f5415-8311-4721-b45e-9065ffce706f'),(48,'craft','m170217_044740_category_branch_limits','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','ebb44803-e043-488c-8e2b-7e90891718e1'),(49,'craft','m170217_120224_asset_indexing_columns','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','c7f570e8-9195-49e8-96db-5278eab7c86e'),(50,'craft','m170223_224012_plain_text_settings','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','88c81acc-38ec-4bba-a71c-b4f39dedfa8f'),(51,'craft','m170227_120814_focal_point_percentage','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','7d983c29-972f-48a0-bfd4-23bae8d42432'),(52,'craft','m170228_171113_system_messages','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','7cc08efb-1f6f-4f07-8439-7006cee60ee5'),(53,'craft','m170303_140500_asset_field_source_settings','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','7de349da-b2e8-43b6-8a2f-adc4502d2fc2'),(54,'craft','m170306_150500_asset_temporary_uploads','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','f90c2fca-3b36-4cad-b2cc-f11095c068f6'),(55,'craft','m170523_190652_element_field_layout_ids','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','2bcac67b-2035-4029-b5f8-0956ded46f96'),(56,'craft','m170621_195237_format_plugin_handles','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','abca398a-cebd-402e-8d9b-89eec317785f'),(57,'craft','m170630_161027_deprecation_line_nullable','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','6926d031-8694-4172-82e0-41e43adb65b7'),(58,'craft','m170630_161028_deprecation_changes','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','d37309e0-cf56-4eaa-944c-61aefb6e1e59'),(59,'craft','m170703_181539_plugins_table_tweaks','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','13835500-2f87-49d1-93cd-86c3e2054a4e'),(60,'craft','m170704_134916_sites_tables','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','7a0e0331-8218-439a-9d55-44876f8fabcd'),(61,'craft','m170706_183216_rename_sequences','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','61aed08f-9f0c-4df1-aadd-3a24da7d98eb'),(62,'craft','m170707_094758_delete_compiled_traits','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','79facee6-eb3c-4382-98c2-0a16607dc811'),(63,'craft','m170731_190138_drop_asset_packagist','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','f747b5a2-5af7-4a06-bdf9-0d4f3f95ffad'),(64,'craft','m170810_201318_create_queue_table','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','967c92ec-17e9-4fe3-9800-d4537f4572c2'),(65,'craft','m170903_192801_longblob_for_queue_jobs','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','b20e50a2-9c03-46f7-81e3-ac2f61fa4cab'),(66,'craft','m170914_204621_asset_cache_shuffle','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','537dff30-31dd-434f-87b4-91f9e3642bfd'),(67,'craft','m171011_214115_site_groups','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','ac05a6ee-c6ba-445f-a99c-41a92c30f159'),(68,'craft','m171012_151440_primary_site','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','4c020523-a751-4c8a-9337-21d9609d5c54'),(69,'craft','m171013_142500_transform_interlace','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','81684d3e-c3b9-4511-a479-767d75a39641'),(70,'craft','m171016_092553_drop_position_select','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','10734986-5b6b-4073-b436-fd10231df1d4'),(71,'craft','m171016_221244_less_strict_translation_method','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','198c0be7-057c-49a4-ad59-5e3350801078'),(72,'craft','m171107_000000_assign_group_permissions','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','0b51484e-9d20-49df-9023-d7a88f7b6cde'),(73,'craft','m171117_000001_templatecache_index_tune','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','5e94933f-c127-4b57-a7bc-0b25a5ea2b32'),(74,'craft','m171126_105927_disabled_plugins','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','35846fce-81ae-4555-b1cf-78c350b153d0'),(75,'craft','m171130_214407_craftidtokens_table','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','00266b7d-f8e2-4383-af06-ab1888568a78'),(76,'craft','m171202_004225_update_email_settings','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','7ad5b623-0d0f-4815-a043-bbd228bcaaff'),(77,'craft','m171204_000001_templatecache_index_tune_deux','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','d9d47285-3cdc-4185-8b1c-667c3d3d02e9'),(78,'craft','m171205_130908_remove_craftidtokens_refreshtoken_column','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','1cca9abb-115c-46c0-b50f-512217f0879e'),(79,'craft','m171218_143135_longtext_query_column','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','3e7e9d09-5a18-42ee-aa1c-ca4d9e0c5293'),(80,'craft','m171231_055546_environment_variables_to_aliases','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','0b08baba-4dd7-41fc-9f9d-cc635c20676d'),(81,'craft','m180113_153740_drop_users_archived_column','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','c02443f7-188b-4e7b-80e0-30ee945f396e'),(82,'craft','m180122_213433_propagate_entries_setting','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','bc48eeaa-7e0e-4162-9ded-975a6316e2e9'),(83,'craft','m180124_230459_fix_propagate_entries_values','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','2a19f204-3af0-406c-b59b-9964ca249f9a'),(84,'craft','m180128_235202_set_tag_slugs','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','404a97b5-1464-4cc7-86ed-b48eb3266952'),(85,'craft','m180202_185551_fix_focal_points','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','3cd826fa-5cb6-4495-b701-3f4bd6ff7c19'),(86,'craft','m180217_172123_tiny_ints','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','0c2405e6-ea3b-4203-9de1-78af1cc9593d'),(87,'craft','m180321_233505_small_ints','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','9eb7e49b-daff-45ca-b3af-7d188d08f41b'),(88,'craft','m180404_182320_edition_changes','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','17e0481c-7081-432d-b387-8d75c69d7f25'),(89,'craft','m180411_102218_fix_db_routes','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','2cb4e88e-285c-4084-bf76-7534e1a80506'),(90,'craft','m180416_205628_resourcepaths_table','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','c5b4074e-1653-4d6e-abc6-028e354581dc'),(91,'craft','m180418_205713_widget_cleanup','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','2a2bd6de-622c-46d1-89e3-64aff5008abe'),(92,'craft','m180425_203349_searchable_fields','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','b3f2f021-fb92-4db3-bc31-629801d6e4aa'),(93,'craft','m180516_153000_uids_in_field_settings','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','41d32ab4-cb01-4106-af2e-d0d0a3410e40'),(94,'craft','m180517_173000_user_photo_volume_to_uid','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','24cb40e6-f1a5-45f4-8103-7fd6a39a6d26'),(95,'craft','m180518_173000_permissions_to_uid','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','142e1a1a-6126-45b4-b384-bcdf7f22b703'),(96,'craft','m180520_173000_matrix_context_to_uids','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','a90845e3-76b7-4f9f-b1cc-7c4af3f3a542'),(97,'craft','m180521_172900_project_config_table','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','1ef3ec21-3e64-4fff-843c-140495c06bce'),(98,'craft','m180521_173000_initial_yml_and_snapshot','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','1d2fc58f-e772-43d6-be07-c9746a2245e2'),(99,'craft','m180731_162030_soft_delete_sites','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','8718862a-d73f-4b42-88d6-2903377485ea'),(100,'craft','m180810_214427_soft_delete_field_layouts','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','03c8e966-079b-4b74-9566-7d4368e92da0'),(101,'craft','m180810_214439_soft_delete_elements','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','c5bf3d04-1b07-40ef-b7fe-45a634f15e04'),(102,'craft','m180824_193422_case_sensitivity_fixes','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','0e8db590-5241-4717-8115-62712c9e9f66'),(103,'craft','m180901_151639_fix_matrixcontent_tables','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','0706f39c-8eb4-4d43-9ac7-912de2f91167'),(104,'craft','m180904_112109_permission_changes','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','44aae54e-5878-4e82-8e9d-5c2cd8bf5915'),(105,'craft','m180910_142030_soft_delete_sitegroups','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','f7fbfdbd-1f47-49ee-9019-2d052ac4e71b'),(106,'craft','m181011_160000_soft_delete_asset_support','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','d75badb4-3acb-499c-965b-0d6781a2335b'),(107,'craft','m181016_183648_set_default_user_settings','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','d57ad264-f930-419e-8b39-b05d9ec77ce5'),(108,'craft','m181017_225222_system_config_settings','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','8388af15-adc9-4962-8414-894284cfcbe3'),(109,'craft','m181018_222343_drop_userpermissions_from_config','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','67839e28-1d1f-489c-b0af-4e10d409fcc7'),(110,'craft','m181029_130000_add_transforms_routes_to_config','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','7bcd0a72-47a7-490b-8b2f-0afec35fd879'),(111,'craft','m181112_203955_sequences_table','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','dca85f85-7df6-4a2f-b774-0ccf218dbf59'),(112,'craft','m181121_001712_cleanup_field_configs','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','1d7df42e-322b-49a4-befd-81d520171208'),(113,'craft','m181128_193942_fix_project_config','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','44ad0c10-4a2f-449f-8d92-8144cf952886'),(114,'craft','m181130_143040_fix_schema_version','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','c7f15469-ab03-4b22-8939-a41a003f8fce'),(115,'craft','m181211_143040_fix_entry_type_uids','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','74a0970d-d825-41c9-af70-6f350da03346'),(116,'craft','m181217_153000_fix_structure_uids','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','270bacd9-318b-4317-9111-d4211f024c7e'),(117,'craft','m190104_152725_store_licensed_plugin_editions','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','5d1ba8a6-9c49-410e-83f6-b979ed63a23e'),(118,'craft','m190108_110000_cleanup_project_config','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','25d2bd85-09fd-4b18-8026-7ae190a39703'),(119,'craft','m190108_113000_asset_field_setting_change','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','c7c9dc81-f71e-4ecd-97eb-dfea2c03dea8'),(120,'craft','m190109_172845_fix_colspan','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','ef9bd480-36df-419e-a763-524d0110ccb7'),(121,'craft','m190110_150000_prune_nonexisting_sites','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','258697bd-ae18-45c5-8529-2880ba459209'),(122,'craft','m190110_214819_soft_delete_volumes','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','5acf3864-580f-434d-a3e4-2e69616a4bd3'),(123,'craft','m190112_124737_fix_user_settings','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','d9ff1671-5763-4829-80c4-a41f26ab7a1c'),(124,'craft','m190112_131225_fix_field_layouts','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','308a6f3f-fd84-40ee-a9d9-d2b935a3d09b'),(125,'craft','m190112_201010_more_soft_deletes','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','174ec4df-6457-4ac9-b152-7c63c426b64d'),(126,'craft','m190114_143000_more_asset_field_setting_changes','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','b902f88f-dcfc-4dd3-a188-e3e41abb5542'),(127,'craft','m190121_120000_rich_text_config_setting','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','42d13a27-6716-43e2-9a65-e2e3a0a6f811'),(128,'craft','m190125_191628_fix_email_transport_password','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','bfbc204d-64c6-4380-9a7b-761c4285a0c0'),(129,'craft','m190128_181422_cleanup_volume_folders','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','6034907a-661c-4599-ac04-b99bc0d12b7c'),(130,'craft','m190205_140000_fix_asset_soft_delete_index','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','d49bd1fa-0292-4bf0-8e7f-dc73d9c3d80c'),(131,'craft','m190218_143000_element_index_settings_uid','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','afa59ff3-3f11-4822-a2a3-4f47cbce5276'),(132,'craft','m190312_152740_element_revisions','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','f12d0739-b425-4fc7-a6bd-4f97f96768ac'),(133,'craft','m190327_235137_propagation_method','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','cf909781-d78c-4c37-bc65-f3e0fca3e772'),(134,'craft','m190401_223843_drop_old_indexes','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','4f350abd-096c-490a-b831-a9abab2f6263'),(135,'craft','m190416_014525_drop_unique_global_indexes','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','af705c17-73fd-4979-918f-763769be81c2'),(136,'craft','m190417_085010_add_image_editor_permissions','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','416bc549-76a7-42a5-9583-d6e5f2a20513'),(137,'craft','m190502_122019_store_default_user_group_uid','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','bc86bc1a-845e-403e-a17f-9dee5929ffb5'),(138,'craft','m190504_150349_preview_targets','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','6584e5e8-0063-40c3-a24b-473fc6fd14e4'),(139,'craft','m190516_184711_job_progress_label','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','b48dc877-db7f-48c0-bb87-5167d5039300'),(140,'craft','m190523_190303_optional_revision_creators','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','e1da71c9-f365-49ad-bad8-8ba6d779b77f'),(141,'craft','m190529_204501_fix_duplicate_uids','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','1da55d6e-a6d1-4a79-894e-3a4347fdc405'),(142,'craft','m190605_223807_unsaved_drafts','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','ac3d4fae-8608-46da-bb1f-2c96658ffa20'),(143,'craft','m190607_230042_entry_revision_error_tables','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','4d353b86-a409-4f5a-9475-c840bb81f8f2'),(144,'craft','m190608_033429_drop_elements_uid_idx','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','3045a1f2-4fc2-4063-88a7-7e36515507eb'),(145,'craft','m190617_164400_add_gqlschemas_table','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','86e646f1-5b9d-434d-a35f-a8d7a2615d1c'),(146,'craft','m190624_234204_matrix_propagation_method','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','704f71c2-e001-40fa-93ec-f4d86b0fb260'),(147,'craft','m190711_153020_drop_snapshots','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','e1823ae1-e1d3-48ca-9083-df0456e47b99'),(148,'craft','m190712_195914_no_draft_revisions','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','d67d88f0-0336-4380-874e-4b28ac9e2d43'),(149,'craft','m190723_140314_fix_preview_targets_column','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','3730108d-e6a3-46f1-8cf7-53b076404da7'),(150,'craft','m190820_003519_flush_compiled_templates','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','f4849adf-086c-4e3e-9e9b-9433c041a240'),(151,'craft','m190823_020339_optional_draft_creators','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','c99c453b-f3aa-4988-89e6-48099fbca3c4'),(152,'craft','m190913_152146_update_preview_targets','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','46e98e65-cb9c-4436-ad40-92a620b748fb'),(153,'craft','m191107_122000_add_gql_project_config_support','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','bd603913-c973-4f2c-90e6-b0fe25c4fc39'),(154,'craft','m191204_085100_pack_savable_component_settings','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','7f6ee83f-f4c5-4405-a9a4-598171fca7a4'),(155,'craft','m191206_001148_change_tracking','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','ec4cf4ad-db3e-46c3-95d6-83da2a38c2c0'),(156,'craft','m191216_191635_asset_upload_tracking','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','56256db8-8e22-4c26-bd51-bb14fdf8e669'),(157,'craft','m191222_002848_peer_asset_permissions','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','aa1a1a06-55ed-4d54-8771-4b844d354476'),(158,'craft','m200127_172522_queue_channels','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','71f292b5-037c-4d3c-9777-29f884cae383'),(159,'craft','m200211_175048_truncate_element_query_cache','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','78c65bdd-6eb4-49d3-ab55-6755fa52638f'),(160,'craft','m200213_172522_new_elements_index','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','9d991780-cc3a-4781-b543-cbb87340f8cc'),(161,'craft','m200228_195211_long_deprecation_messages','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','47c941fc-14e2-4408-9e42-1e9dc06addee'),(162,'craft','m200306_054652_disabled_sites','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','9752218d-7051-417d-bf94-5861605cbfca'),(163,'craft','m200522_191453_clear_template_caches','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','76ef2b50-fb3f-4379-8835-d0f94e7cb385'),(164,'craft','m200606_231117_migration_tracks','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','3c645eaa-bda6-4b11-8836-d0412f8edb0f'),(165,'craft','m200619_215137_title_translation_method','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','51e58865-ff27-4ea9-b7a7-6ff0428099dc'),(166,'craft','m200620_005028_user_group_descriptions','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','1689215a-d50b-44a3-9304-c4c4c8a90dfe'),(167,'craft','m200620_230205_field_layout_changes','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','1a22dd5e-2b3e-429d-8f65-8c289251e63b'),(168,'craft','m200625_131100_move_entrytypes_to_top_project_config','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','166f0f66-9775-4abe-98fc-16a2a50581f0'),(169,'craft','m200629_112700_remove_project_config_legacy_files','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','479f8b55-5edf-45fb-ab4f-d53ccad60dc6'),(170,'craft','m200630_183000_drop_configmap','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','9871f925-b9ef-4372-bbce-2035d60cd344'),(171,'craft','m200715_113400_transform_index_error_flag','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','a3e43014-4b5f-4d54-9134-73091413ded1'),(172,'craft','m200716_110900_replace_file_asset_permissions','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','aa1d66d0-9451-4c05-9765-9cdd1d5703bf'),(173,'craft','m200716_153800_public_token_settings_in_project_config','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','8c7a6dc7-bf6f-4f3e-aaae-53076a17202b'),(174,'craft','m200720_175543_drop_unique_constraints','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','5c03a279-075c-49fd-967c-55db48c17d2e'),(175,'craft','m200825_051217_project_config_version','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','04ec2400-5aef-4b10-9829-3a31f7d799e1'),(176,'craft','m201116_190500_asset_title_translation_method','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','0f860784-ec11-498e-841e-e3a352bed9d1'),(177,'craft','m201124_003555_plugin_trials','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','4cac65e5-a860-4539-b522-ede0846b880d'),(178,'craft','m210209_135503_soft_delete_field_groups','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','b51f88b6-c542-4c1b-b49d-f094b4035446'),(179,'craft','m210212_223539_delete_invalid_drafts','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','c951fd77-eede-47f4-88d4-7bc276df8ef1'),(180,'craft','m210214_202731_track_saved_drafts','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','864baf9d-7a22-4a26-b1a5-827080c73a79'),(181,'craft','m210223_150900_add_new_element_gql_schema_components','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','389eeb2d-9e4b-40e8-a12c-9b480fa2013a'),(182,'craft','m210302_212318_canonical_elements','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','a205007e-4d43-470c-b18a-2decb17399d0'),(183,'craft','m210326_132000_invalidate_projectconfig_cache','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','b4060552-af6e-423a-a863-5f3882c65074'),(184,'craft','m210329_214847_field_column_suffixes','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','fd985cd2-42d3-4da9-bcb3-ae39c3bf9e66'),(185,'craft','m210331_220322_null_author','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','3fc18657-994e-41d6-9e9a-d092ae0ef574'),(186,'craft','m210405_231315_provisional_drafts','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','ea11e1e9-7e97-4a97-8df7-125f7c14eb90'),(187,'craft','m210602_111300_project_config_names_in_config','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','9b0be3a8-86c1-4d5c-9147-f44332332826'),(188,'craft','m210611_233510_default_placement_settings','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','66d123c6-e55e-42e2-be2e-f9bd45338c16'),(189,'craft','m210613_145522_sortable_global_sets','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','f142e5dd-323b-4ada-beef-ba9a80f003e4'),(190,'craft','m210613_184103_announcements','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','3f579749-0274-4f1f-a4c1-7f2a4cc3046b'),(191,'craft','m210829_000000_element_index_tweak','2022-01-13 16:08:05','2022-01-13 16:08:05','2022-01-13 16:08:05','c2e6e5a4-3d98-44d3-89dd-975d38841325');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `projectconfig` VALUES ('dateModified','1642105009'),('email.fromEmail','\"taylor+craftvue@ellcreative.com\"'),('email.fromName','\"Nuxt\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('fieldGroups.76566381-39cb-4a0a-979e-9ba75b430b12.name','\"Common\"'),('graphql.publicToken.enabled','true'),('graphql.publicToken.expiryDate','null'),('graphql.schemas.b3e1d1ca-562d-48d1-9935-82d27aa939d9.isPublic','true'),('graphql.schemas.b3e1d1ca-562d-48d1-9935-82d27aa939d9.name','\"Public Schema\"'),('graphql.schemas.e9cad64a-269f-458b-983e-4f839f117801.isPublic','false'),('graphql.schemas.e9cad64a-269f-458b-983e-4f839f117801.name','\"Frontend\"'),('meta.__names__.76566381-39cb-4a0a-979e-9ba75b430b12','\"Common\"'),('meta.__names__.b3e1d1ca-562d-48d1-9935-82d27aa939d9','\"Public Schema\"'),('meta.__names__.e06c8337-4b69-45aa-95f7-d6faf18148c0','\"Nuxt\"'),('meta.__names__.e50799a7-aaec-4292-8d59-1231573c09c0','\"Nuxt\"'),('meta.__names__.e9cad64a-269f-458b-983e-4f839f117801','\"Frontend\"'),('siteGroups.e50799a7-aaec-4292-8d59-1231573c09c0.name','\"Nuxt\"'),('sites.e06c8337-4b69-45aa-95f7-d6faf18148c0.baseUrl','\"$FRONTEND_SITE_URL\"'),('sites.e06c8337-4b69-45aa-95f7-d6faf18148c0.handle','\"default\"'),('sites.e06c8337-4b69-45aa-95f7-d6faf18148c0.hasUrls','true'),('sites.e06c8337-4b69-45aa-95f7-d6faf18148c0.language','\"en-US\"'),('sites.e06c8337-4b69-45aa-95f7-d6faf18148c0.name','\"Nuxt\"'),('sites.e06c8337-4b69-45aa-95f7-d6faf18148c0.primary','true'),('sites.e06c8337-4b69-45aa-95f7-d6faf18148c0.siteGroup','\"e50799a7-aaec-4292-8d59-1231573c09c0\"'),('sites.e06c8337-4b69-45aa-95f7-d6faf18148c0.sortOrder','1'),('system.edition','\"pro\"'),('system.live','true'),('system.name','\"$SYSTEM_NAME\"'),('system.retryDuration','null'),('system.schemaVersion','\"3.7.8\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.requireEmailVerification','true');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `resourcepaths` VALUES ('19a99add','@app/web/assets/elementresizedetector/dist'),('1b26debb','@app/web/assets/userpermissions/dist'),('1ffbbb2e','@app/web/assets/garnish/dist'),('29b910f9','@app/web/assets/craftsupport/dist'),('2b8e2f38','@app/web/assets/cp/dist'),('30fa13cc','@app/web/assets/recententries/dist'),('5467c143','@app/web/assets/generalsettings/dist'),('5c2f692','@app/web/assets/utilities/dist'),('5d55e0a1','@app/web/assets/updateswidget/dist'),('5dd310df','@app/web/assets/fabric/dist'),('5e64db07','@app/web/assets/fileupload/dist'),('60d5deec','@app/web/assets/pluginstore/dist'),('625c61e0','@app/web/assets/d3/dist'),('63d3c752','@bower/jquery/dist'),('79df39bf','@app/web/assets/iframeresizer/dist'),('87f5c1dc','@app/web/assets/selectize/dist'),('89c8cbf7','@app/web/assets/jquerytouchevents/dist'),('9323573d','@app/web/assets/picturefill/dist'),('a17be0cd','@app/web/assets/velocity/dist'),('aad8c427','@modules/sitemodule/assetbundles/sitemodule/dist'),('b36933d1','@app/web/assets/jqueryui/dist'),('b6842e45','@app/web/assets/jquerypayment/dist'),('bb6409e5','@app/web/assets/dashboard/dist'),('c7dbf3a8','@app/web/assets/vue/dist'),('d0b0b75e','@app/web/assets/feed/dist'),('e863acd1','@app/web/assets/focusvisible/dist'),('ed87f5e0','@app/web/assets/xregexp/dist'),('f00f0b33','@app/web/assets/axios/dist'),('f90733e3','@app/web/assets/admintable/dist'),('f95b7283','@app/web/assets/dbbackup/dist'),('ff7fcd6e','@app/web/assets/timepicker/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `searchindex` VALUES (1,'username',0,1,' admin '),(1,'firstname',0,1,''),(1,'lastname',0,1,''),(1,'fullname',0,1,''),(1,'email',0,1,' taylor craftvue ellcreative com '),(1,'slug',0,1,'');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sitegroups` VALUES (1,'Nuxt','2022-01-13 16:08:04','2022-01-13 16:08:04',NULL,'e50799a7-aaec-4292-8d59-1231573c09c0');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sites` VALUES (1,1,1,1,'Nuxt','default','en-US',1,'$FRONTEND_SITE_URL',1,'2022-01-13 16:08:04','2022-01-13 16:08:04',NULL,'e06c8337-4b69-45aa-95f7-d6faf18148c0');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `userpreferences` VALUES (1,'{\"language\":\"en-US\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES (1,'admin',NULL,NULL,NULL,'taylor+craftvue@ellcreative.com','$2y$13$m8g2QCieGGRWUWSHg.goyevWBN7J815yXNS0/Wtfm5Ea.mliSGNv2',1,0,0,0,'2022-01-13 19:21:02',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2022-01-13 16:08:04','2022-01-13 16:08:04','2022-01-13 19:21:02','edbaf4df-bbd4-429e-aa8a-eb5bbba5aede');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"siteId\":1,\"section\":\"*\",\"limit\":10}',1,'2022-01-13 16:08:07','2022-01-13 16:08:07','77a6eeca-9956-43de-8511-e962dad89c67'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2022-01-13 16:08:07','2022-01-13 16:08:07','20b4a8e5-673d-4a2a-a87e-70e890c427a3'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2022-01-13 16:08:07','2022-01-13 16:08:07','92093045-4b58-448b-812a-0abca434e69e'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https://craftcms.com/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2022-01-13 16:08:07','2022-01-13 16:08:07','92c71284-012d-4b88-8704-5805218f08e6');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'craftvue_db_dev'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-13 20:19:44
